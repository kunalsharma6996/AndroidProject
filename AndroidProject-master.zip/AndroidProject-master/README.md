# AndroidProject
Before starting debugging, fork the code and make a branch by your team name and update all the bugs in that branch only.
#About the Appication
Google maps does not have all the places registered, so the idea is that in the add button at the bottom right corner, you can add your
favourite place and then keep a track of them by using categories.
Explore all the buttons and find bugs.
#Submission
After pushing all your code upload a text file explaing all the bugs that you found and solved.
